"""AmLogic s922x pin names"""
# pylint: disable=wildcard-import,unused-wildcard-import
from adafruit_blinka.microcontroller.amlogic.meson_g12_common.pin import *
