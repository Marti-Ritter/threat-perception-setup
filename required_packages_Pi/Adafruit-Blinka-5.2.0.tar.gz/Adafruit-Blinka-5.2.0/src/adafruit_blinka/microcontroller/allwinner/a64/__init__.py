"""Definition for the AllWinner A64 chip"""
