Simple test
------------

Ensure your device works with this simple test.

.. literalinclude:: ../examples/lis3dh_simpletest.py
    :caption: examples/lis3dh_simpletest.py
    :linenos:

Here are some additional examples:

.. literalinclude:: ../examples/lis3dh_tap.py
    :caption: examples/lis3dh_tap.py
    :linenos:

.. literalinclude:: ../examples/lis3dh_adc.py
    :caption: examples/lis3dh_adc.py
    :linenos:

.. literalinclude:: ../examples/lis3dh_spinner.py
    :caption: examples/lis3dh_spinner.py
    :linenos:
