
.. If you created a package, create one automodule per module in the package.

.. automodule:: adafruit_bus_device.i2c_device
   :members:

.. automodule:: adafruit_bus_device.spi_device
    :members:
