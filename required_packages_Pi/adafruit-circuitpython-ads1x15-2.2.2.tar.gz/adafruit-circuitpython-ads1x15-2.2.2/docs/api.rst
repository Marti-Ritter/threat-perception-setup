
.. If you created a package, create one automodule per module in the package.

.. automodule:: adafruit_ads1x15.ads1x15
   :members:

.. automodule:: adafruit_ads1x15.ads1015
   :members:

.. automodule:: adafruit_ads1x15.ads1115
   :members:

.. automodule:: adafruit_ads1x15.analog_in
   :members: